# 2025-11-15T18:14:23.956062500
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/ME6Workspace")

platform = client.create_platform_component(name = "platform",hw_design = "C:/Users/ChampBern/Documents/College_UPD_EEEI/CoE168/CoE168_ME6_Gallego_Final/design_1_wrapper.xsa",os = "standalone",cpu = "microblaze_riscv_0",domain_name = "standalone_microblaze_riscv_0")

comp = client.create_app_component(name="app_component",platform = "C:/ME6Workspace/platform/export/platform/platform.xpfm",domain = "standalone_microblaze_riscv_0")

platform = client.get_component(name="platform")
status = platform.build()

comp = client.get_component(name="app_component")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

vitis.dispose()

