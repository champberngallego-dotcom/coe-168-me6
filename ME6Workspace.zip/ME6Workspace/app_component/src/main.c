#include <stdio.h>
#include "xparameters.h"
#include "xgpio.h" 
#include "xil_printf.h" 
#include "xil_types.h" 
#include "sleep.h" 

// --- Hardware Device IDs (from xparameters.h) ---
// Per the basis code: Left = GPIO 3, Right = GPIO 2
#define SSD_LEFT_ID     XPAR_XGPIO_3_BASEADDR  // Left 2-digit display
#define SSD_RIGHT_ID    XPAR_XGPIO_2_BASEADDR  // Right 2-digit display
#define SSD_CHANNEL     1                      // Both GPIOs use channel 1

// --- SSD Driver Protocol (from Verilog module) ---
#define MODE_HEX        0x000  // Display 8-bit hex value (00-FF)
#define MODE_SPECIAL    0x100  // Enable special mode (bit 8 = 1)
                               // Lower 8 bits select special char

// --- Special Character Codes ---
// (Using placeholder codes, update these to match your Verilog)
#define CODE_CB         0xF0   // 0xF0-0xFF displays "CB"
#define CODE_GG         0xE0   // 0xE0-0xEF displays "GG"

// --- Global GPIO Device Instances ---
// We need two separate instances for the two GPIO peripherals
XGpio ssd_left_device;
XGpio ssd_right_device;


/*****************************************************************************/
/**
* @brief  Updates both 2-digit SSDs with new 9-bit codes.
*
* @param  left_code: The 9-bit code for the left display (GPIO 3).
* @param  right_code: The 9-bit code for the right display (GPIO 2).
*
* @return None.
******************************************************************************/
// Updates both 2-digit SSDs with new 9-bit codes.
void update_ssds(u32 left_code, u32 right_code)
{
    // Write the 9-bit code to the left SSD controller
    XGpio_DiscreteWrite(&ssd_left_device, SSD_CHANNEL, left_code);

    // Write the 9-bit code to the right SSD controller
    XGpio_DiscreteWrite(&ssd_right_device, SSD_CHANNEL, right_code);
}


/*****************************************************************************/
/**
* @brief  Reads a full line of text from UART input.
* Handles backspace and echoes characters.
*
* @param  buf: Pointer to the character buffer to store the line.
* @param  max_len: Maximum number of characters to read (buffer size).
*
* @return None.
******************************************************************************/
// Reads a full line of text from UART input.
void read_line(char* buf, int max_len)
{
    int i = 0;
    char c;

    while (1) {
        // Read one character from UART
        c = inbyte();

        // Handle Backspace
        if (c == '\b' || c == 127) {
            if (i > 0) {
                xil_printf("\b \b"); // Erase character on terminal
                i--;
            }
            continue;
        }

        // Handle Enter/Newline
        if (c == '\n' || c == '\r') {
            buf[i] = 0; // Null-terminate the string
            xil_printf("\r\n"); // Echo newline
            return;
        }

        // Handle regular characters
        if (i < max_len - 1) {
            buf[i++] = c;
            xil_printf("%c", c); // Echo character
        }
    }
}


/*****************************************************************************/
/**
* @brief  Checks if a string represents a valid integer (with optional '-').
*
* @param  s: The null-terminated string to check.
*
* @return 1 if the string is a valid integer, 0 otherwise.
******************************************************************************/
// Checks if a string represents a valid integer (with optional '-').
int is_valid_integer(const char* s)
{
    if (s[0] == 0) return 0; // Empty string is not valid

    int i = 0;
    // Check for optional leading minus sign
    if (s[0] == '-') {
        i = 1;
        // If string is ONLY "-", it's not a valid number
        if (s[1] == 0) return 0;
    }

    // Check that all remaining characters are digits
    for (; s[i]; i++) {
        if (s[i] < '0' || s[i] > '9') {
            return 0; // Found a non-digit character
        }
    }
    
    return 1; // All checks passed
}


// --- Custom C-Library Function Implementations ---

/**
* @brief  Converts a string to an integer (custom atoi).
* @param  s: The null-terminated string to convert.
* @return The integer value.
*/
int custom_atoi(const char *s) {
    int res = 0;
    int sign = 1;
    int i = 0;

    if (s[0] == '-') {
        sign = -1;
        i = 1;
    }

    for (; s[i]; ++i) {
        if (s[i] >= '0' && s[i] <= '9') {
            res = res * 10 + (s[i] - '0');
        } else {
            break; // Stop at non-digit
        }
    }
    return res * sign;
}

/**
* @brief  Finds the first occurrence of a character in a string (custom strchr).
* @param  s: The string to search.
* @param  c: The character to find.
* @return A pointer to the char, or NULL if not found.
*/
char* custom_strchr(const char *s, int c) {
    while (*s != (char)c) {
        if (!*s) { // Reached null terminator
            return NULL;
        }
        s++;
    }
    return (char*)s;
}

/**
* @brief  Finds the first occurrence of a substring (custom strstr).
* @param  haystack: The string to search in.
* @param  needle: The substring to find.
* @return A pointer to the beginning of the substring, or NULL if not found.
*/
char* custom_strstr(const char *haystack, const char *needle) {
    if (!*needle) {
        return (char*)haystack; // Empty needle
    }
    char *p1 = (char*)haystack;
    while (*p1) {
        char *p1_begin = p1, *p2 = (char*)needle;
        while (*p1 && *p2 && *p1 == *p2) {
            p1++;
            p2++;
        }
        if (!*p2) {
            return p1_begin; // Found
        }
        p1 = p1_begin + 1; // Advance haystack
    }
    return NULL;
}

/**
* @brief  Copies N characters from src to dest (custom strncpy).
* @note   This version does *not* null-pad like the standard.
* The caller is responsible for null termination.
*
* @param  dest: Destination buffer.
* @param  src: Source string.
* @param  n: Maximum number of characters to copy.
* @return Pointer to dest.
*/
char* custom_strncpy(char *dest, const char *src, int n) {
    int i;
    for (i = 0; i < n; i++) {
        if (src[i] == '\0') {
             break; // Stop copying at null
        }
        dest[i] = src[i];
    }
    // Note: Relies on caller to null-terminate dest[n]
    return dest;
}

/**
* @brief  Copies a string from src to dest (custom strcpy).
*
* @param  dest: Destination buffer (must be large enough).
* @param  src: Source string.
* @return Pointer to dest.
*/
char* custom_strcpy(char *dest, const char *src) {
    char *start = dest;
    while (*src != '\0') {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0'; // Null-terminate
    return start;
}


/*****************************************************************************/
/**
* @brief  Main function for the calculator.
*
* @param  None.
*
* @return XST_SUCCESS on success, XST_FAILURE on hardware init error.
******************************************************************************/
int main()
{
    int status;
    char input_line[64];
    XGpio_Config *cfg_ptr;

    // --- Initialize LEFT SSD (GPIO 3) ---
    // Using 2-step init
    cfg_ptr = XGpio_LookupConfig(SSD_LEFT_ID);
    if (cfg_ptr == NULL) {
        xil_printf("Error: SSD LEFT (GPIO 3) LookupConfig failed!\r\n");
        return XST_FAILURE;
    }
    status = XGpio_CfgInitialize(&ssd_left_device, cfg_ptr, cfg_ptr->BaseAddress);
    if (status != XST_SUCCESS) {
        xil_printf("Error: SSD LEFT (GPIO 3) CfgInitialize failed!\r\n");
        return XST_FAILURE;
    }

    // --- Initialize RIGHT SSD (GPIO 2) ---
    // Using 2-step init
    cfg_ptr = XGpio_LookupConfig(SSD_RIGHT_ID);
    if (cfg_ptr == NULL) {
        xil_printf("Error: SSD RIGHT (GPIO 2) LookupConfig failed!\r\n");
        return XST_FAILURE;
    }
    status = XGpio_CfgInitialize(&ssd_right_device, cfg_ptr, cfg_ptr->BaseAddress);
    if (status != XST_SUCCESS) {
        xil_printf("Error: SSD RIGHT (GPIO 2) CfgInitialize failed!\r\n");
        return XST_FAILURE;
    }

    // --- Set Data Direction for BOTH devices to Output ---
    // 0 = Output, 1 = Input. We are only writing to the SSDs.
    XGpio_SetDataDirection(&ssd_left_device, SSD_CHANNEL, 0x0);
    XGpio_SetDataDirection(&ssd_right_device, SSD_CHANNEL, 0x0);

    xil_printf("=== ME6 Calculator Started ===\r\n");

    // --- Startup Sequence ---
    // Display "CB" on left, "GG" on right (using special mode)
    update_ssds(MODE_SPECIAL | CODE_CB, MODE_SPECIAL | CODE_GG);
    usleep(1000000); // 1 second delay

    // Reset display to "0000" (using hex mode)
    update_ssds(MODE_HEX | 0x00, MODE_HEX | 0x00);

    // --- Main Application Loop ---
    while (1)
    {
        xil_printf("\r\nEnter Query: ");
        read_line(input_line, 64);

        if (input_line[0] == 0) continue; // Skip empty input

        // --- Parse Operator ---
        char *op_ptr = NULL;
        char op = 0;
        int op_len = 1; // Most operators are 1 char

        // Check for 2-character operators first
        if ((op_ptr = custom_strstr(input_line, "<<"))) {
            op = '<';
            op_len = 2;
        } else if ((op_ptr = custom_strstr(input_line, ">>"))) {
            op = '>';
            op_len = 2;
        } 
        // Then check for 1-character operators
        else if ((op_ptr = custom_strchr(input_line, '+'))) op = '+';
        else if ((op_ptr = custom_strchr(input_line, '-'))) op = '-';
        else if ((op_ptr = custom_strchr(input_line, '*'))) op = '*';
        else if ((op_ptr = custom_strchr(input_line, '/'))) op = '/';
        else if ((op_ptr = custom_strchr(input_line, '%'))) op = '%';
        else {
            xil_printf("Error: Invalid Operator\r\n");
            update_ssds(MODE_SPECIAL | CODE_CB, MODE_SPECIAL | CODE_GG);
            continue;
        }

        // --- Split Operands ---
        char left_str[32], right_str[32];
        
        int op_pos = (int)(op_ptr - input_line);
        
        // Copy left part
        custom_strncpy(left_str, input_line, op_pos);
        left_str[op_pos] = 0; // Null-terminate
        
        // Copy right part
        custom_strcpy(right_str, op_ptr + op_len);

        // Note: doesn't handle whitespace
        
        // --- Validate Inputs ---
        if (!is_valid_integer(left_str) || !is_valid_integer(right_str)) {
            xil_printf("Error: Invalid Input (non-numeric)\r\n");
            update_ssds(MODE_SPECIAL | CODE_CB, MODE_SPECIAL | CODE_GG);
            continue;
        }

        // Convert to integers
        int n1 = custom_atoi(left_str);
        int n2 = custom_atoi(right_str);

        // Per PDF spec, operands must be positive
        if (n1 < 0 || n2 < 0) {
            xil_printf("Error: Invalid Input (negative operands not allowed)\r\n");
            update_ssds(MODE_SPECIAL | CODE_CB, MODE_SPECIAL | CODE_GG);
            continue;
        }

        // --- Perform Operation ---
        int result = 0;
        int error = 0;

        switch (op) {
            case '+': result = n1 + n2; break;
            case '-': result = n1 - n2; break;
            case '*': result = n1 * n2; break;
            case '/':
                if (n2 == 0) {
                    xil_printf("Error: Divide by zero\r\n");
                    error = 1;
                } else {
                    result = n1 / n2;
                }
                break;
            case '%':
                if (n2 == 0) {
                    xil_printf("Error: Modulo by zero\r\n");
                    error = 1;
                } else {
                    result = n1 % n2;
                }
                break;
            case '<': result = n1 << n2; break; // Shift Left
            case '>': result = n1 >> n2; break; // Shift Right
            
            // This default case should not be reachable due to parsing above
            default: 
                xil_printf("Error: Invalid Operator\r\n"); 
                error = 1; 
                break;
        }

        if (error) {
            update_ssds(MODE_SPECIAL | CODE_CB, MODE_SPECIAL | CODE_GG);
            continue;
        }

        // --- Check Overflow ---
        // Display range is -FFF to FFFF (12-bit negative, 16-bit positive)
        // 0xFFFF = 65535
        // -0xFFF = -4095
        if (result > 0xFFFF || result < -0xFFF) {
            xil_printf("Overflow: %d (cannot display on SSD)\r\n", result);
            update_ssds(MODE_SPECIAL | CODE_CB, MODE_SPECIAL | CODE_GG);
            continue;
        }

        // --- Display Result ---
        xil_printf("Result = %d\r\n", result);

        if (result >= 0) {
            // --- POSITIVE RESULT ---
            // Display as 4-digit hex (16 bits)
            // Left SSD (GPIO 3) gets upper 8 bits
            u32 left_val = (result >> 8) & 0xFF;
            // Right SSD (GPIO 2) gets lower 8 bits
            u32 right_val 
            = result & 0xFF;

            update_ssds(MODE_HEX | left_val, MODE_HEX | right_val);
            
        } else {
            // --- NEGATIVE RESULT ---
            // Display as "-XXX" (12 bits)
            int abs_val = -result;
            
            // Left SSD (GPIO 3) gets special negative code + upper 4 bits
            // e.g., to show "-F", send 0x0F
            u32 left_val = (abs_val >> 8) & 0xF; 
            
            // Right SSD (GPIO 2) gets lower 8 bits
            u32 right_val = abs_val & 0xFF;

            // Use SPECIAL mode for the left display to show the negative sign
            update_ssds(MODE_SPECIAL | left_val, MODE_HEX | right_val);
        }
    }

    // Code will not reach here
    return 0;
}